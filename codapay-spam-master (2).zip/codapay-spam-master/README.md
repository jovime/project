# Codapay Spam SMS

command :
 - apt-get install nodejs
 - git clone https://github.com/revan-ar/codapay-spam.git
 - cd codapay-spam
 - node spam.js --target nomortargetmu jumlah spam, lebih jelasnya lihat gambar dibawah ini 

![Example command](https://i.ibb.co/C0FhDLM/Screenshot-20200131-003137.jpg)

 - contoh jika berhasil menjalankan tool spam ini

![Running Success](https://i.ibb.co/w0FVYCV/Screenshot-20200131-003830.jpg)
