<?php

$banner = "\e[36;1m                                                                                 
                                                                                 
           #         ######   
           #    #             
  ######   #    #  ########## 
           #    #  # J  H  O      
           #######        ##  
##########      #       ##    
                #     ##      
                              
                                                                                 
[#]  Spam SMS [#]    
                                   
Author : JHO                  
Team   : IndoSec                   
Github : https//github.com/jovime/\n\e[0;1m";
                                                                                 
                                                                                                                                                                 
sleep(3);
echo $banner;